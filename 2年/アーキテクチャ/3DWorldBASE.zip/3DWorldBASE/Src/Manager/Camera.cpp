#include "Camera.h"

Camera::Camera(void)
{
	pos_ = { 0.0f, 0.0f, 0.0f };
	angles_ = { 0.0f, 0.0f, 0.0f };
}

Camera::~Camera(void)
{
}

void Camera::Init(void)
{
}

void Camera::Update(void)
{
}

void Camera::SetBeforeDraw(void)
{
}

void Camera::Draw(void)
{
}

void Camera::Release(void)
{
}

VECTOR Camera::GetPos(void) const
{
	return VECTOR();
}

VECTOR Camera::GetAngles(void) const
{
	return VECTOR();
}
