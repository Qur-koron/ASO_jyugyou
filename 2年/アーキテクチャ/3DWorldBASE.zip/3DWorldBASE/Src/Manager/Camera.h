#pragma once
#include <DxLib.h>

class Camera
{

public:

	Camera(void);
	~Camera(void);

	void Init(void);
	void Update(void);
	void SetBeforeDraw(void);
	void Draw(void);
	void Release(void);

	VECTOR GetPos(void) const;
	VECTOR GetAngles(void) const;

private:

	// �J�����̈ʒu
	VECTOR pos_;

	// �J�����̊p�x(rad)
	VECTOR angles_;

};

